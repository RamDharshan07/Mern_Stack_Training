import './App.css'
import Addtask from './Addtask'
import Taskview from './Taskview'

function App() {

  return (
    <>
      <Addtask/>
      
    </>
  )
}

export default App
